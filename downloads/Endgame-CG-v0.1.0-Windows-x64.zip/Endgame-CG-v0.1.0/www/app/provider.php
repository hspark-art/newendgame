<?php
declare(strict_types=1);

function provider_validate(array $players, array $data): array
{
    if (($players['_mock'] ?? false) !== true || ($data['_mock'] ?? false) !== true
        || !is_array($players['players'] ?? null) || !is_array($data['matches'] ?? null)) {
        throw new RuntimeException('MOCK 데이터 형식이 올바르지 않습니다.');
    }
    $ids = $seen = [];
    foreach ($players['players'] as $player) {
        if (!is_array($player) || !is_string($player['id'] ?? null) || !is_string($player['name'] ?? null)
            || trim($player['name']) === '' || isset($ids[$player['id']])
            || !in_array($player['race'] ?? '', ['P', 'T', 'Z'], true)) {
            throw new RuntimeException('선수 MOCK 데이터가 올바르지 않습니다.');
        }
        $ids[$player['id']] = $player;
    }
    foreach ($data['matches'] as $match) {
        if (!is_array($match) || !is_string($match['id'] ?? null) || isset($seen[$match['id']])
            || !isset($ids[$match['a'] ?? ''], $ids[$match['b'] ?? '']) || $match['a'] === $match['b']
            || ($match['a_race'] ?? '') !== $ids[$match['a']]['race']
            || ($match['b_race'] ?? '') !== $ids[$match['b']]['race']
            || !is_int($match['a_score'] ?? null) || !is_int($match['b_score'] ?? null)
            || min($match['a_score'], $match['b_score']) < 0 || max($match['a_score'], $match['b_score']) !== 5
            || $match['a_score'] === $match['b_score']) {
            throw new RuntimeException('경기 MOCK 데이터가 올바르지 않습니다.');
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($match['date'] ?? ''));
        $winner = $match['a_score'] > $match['b_score'] ? $match['a'] : $match['b'];
        if (!$date || $date->format('Y-m-d') !== $match['date'] || ($match['winner'] ?? '') !== $winner) {
            throw new RuntimeException('경기 날짜 또는 승자가 올바르지 않습니다.');
        }
        $seen[$match['id']] = true;
    }
    return ['players' => $ids, 'matches' => $data['matches'], 'mock' => true];
}

function provider_load(string $source = 'mock'): array
{
    if ($source !== 'mock') {
        throw new InvalidArgumentException('현재는 MOCK 소스만 지원합니다.');
    }
    $read = static function (string $name): array {
        $raw = file_get_contents(__DIR__ . '/data/mock/' . $name . '.json');
        if ($raw === false) {
            throw new RuntimeException('MOCK 파일을 읽지 못했습니다.');
        }
        return json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    };
    return provider_validate($read('players'), $read('matches'));
}
