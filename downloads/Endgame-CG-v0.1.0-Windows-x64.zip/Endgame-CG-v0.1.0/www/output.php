<?php
require_once __DIR__ . '/app/bootstrap.php';
cg_headers();
try {
    $output = cg_output_request();
} catch (CgError $error) {
    http_response_code($error->status);
    exit(cg_h($error->getMessage()));
}
?>
<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>끝장전 CG 출력</title><link rel="stylesheet" href="assets/cg.css"><link rel="stylesheet" href="assets/output.css"><script src="assets/output.js" defer></script></head><body>
<main id="canvas"><div id="cg-output" class="cg-output<?= $output['visible'] ? ' visible' : '' ?>" style="right:<?= (int) $output['display']['right'] ?>px;bottom:<?= (int) $output['display']['bottom'] ?>px;transform:scale(<?= (int) $output['display']['scale_pct'] / 100 ?>)"><?= $output['html'] ?></div></main>
<script type="application/json" id="initial-output"><?= cg_json($output) ?></script>
</body></html>
