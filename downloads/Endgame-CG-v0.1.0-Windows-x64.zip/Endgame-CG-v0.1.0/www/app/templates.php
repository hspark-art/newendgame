<?php
declare(strict_types=1);

function cg_h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function rwr_params(array $input, array $data): array
{
    $result = [];
    foreach (['a', 'b'] as $side) {
        $id = $input[$side . '_id'] ?? null;
        $race = $input[$side . '_race'] ?? null;
        if (!is_string($id) || !isset($data['players'][$id]) || !($data['players'][$id]['selectable'] ?? false)
            || !in_array($race, ['P', 'T', 'Z'], true)) {
            throw new CgError('VALIDATION', '선수와 상대 종족을 선택해 주세요.', 422);
        }
        $result[$side . '_id'] = $id;
        $result[$side . '_race'] = $race;
    }
    return $result;
}

function rwr_build_auto(array $params, array $data): array
{
    $cols = [];
    foreach (['a', 'b'] as $side) {
        $record = stats_race_record($data['matches'], $params[$side . '_id'], $params[$side . '_race']);
        $cols[] = ['name' => $data['players'][$params[$side . '_id']]['name'], 'race' => $params[$side . '_race']]
            + $record + ['winRate' => stats_rate_tenths($record['wins'], $record['losses'])];
    }
    return ['title' => '중계진 스타 끝장전 상대 종족 승률', 'cols' => $cols];
}

function rwr_present(array $final): array
{
    return ['title' => $final['title'], 'cols' => array_map(static function (array $col): array {
        $rate = $col['winRate'];
        return ['head' => $col['name'] . ' vs ' . $col['race'],
            'record' => $col['games'] === 0 ? '자료 없음' : $col['wins'] . '승 ' . $col['losses'] . '패',
            'rate' => $rate === null ? '0경기 · 집계 기록 없음' : '(' . intdiv($rate, 10) . '.' . ($rate % 10) . '%)'];
    }, $final['cols'])];
}

function cg_render(array $view): string
{
    $html = '<section class="cg-card"><header>' . cg_h($view['title']) . '</header><div class="cg-columns">';
    foreach ($view['cols'] as $col) {
        $html .= '<div class="cg-column"><h2>' . cg_h($col['head']) . '</h2><div class="cg-record">'
            . cg_h($col['record']) . '</div><div class="cg-rate">' . cg_h($col['rate']) . '</div></div>';
    }
    return $html . '</div><span class="cg-mock">MOCK · 실제 기록 아님</span></section>';
}
