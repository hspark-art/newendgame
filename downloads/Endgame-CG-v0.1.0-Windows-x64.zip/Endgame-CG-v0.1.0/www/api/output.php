<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
cg_api(static function (): array {
    $output = cg_output_request();
    if (isset($_GET['since']) && is_string($_GET['since']) && $_GET['since'] === (string) $output['rev']) {
        return ['same' => true, 'rev' => $output['rev']];
    }
    return $output;
});
