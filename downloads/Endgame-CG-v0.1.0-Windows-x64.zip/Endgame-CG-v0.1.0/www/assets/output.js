'use strict';
(() => {
  const element = document.getElementById('cg-output');
  let current = JSON.parse(document.getElementById('initial-output').textContent);
  const params = new URLSearchParams(location.search);
  const channel = params.get('channel') || 'program';
  const layer = params.get('layer') || '1';
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const animate = async className => {
    element.classList.add(className);
    await wait(matchMedia('(prefers-reduced-motion: reduce)').matches ? 1 : 350);
    element.classList.remove(className);
  };
  async function apply(next) {
    if (next.rev <= current.rev) return;
    const replace = next.take_id !== current.take_id || next.html !== current.html;
    const animated = channel === 'program' && next.in === 'anim';
    if (current.visible && animated && (replace || !next.visible)) await animate('leaving');
    element.classList.remove('visible');
    if (replace) element.innerHTML = next.html;
    element.style.right = `${next.display.right}px`;
    element.style.bottom = `${next.display.bottom}px`;
    element.style.transform = `scale(${next.display.scale_pct / 100})`;
    if (next.visible) {
      element.classList.add('visible');
      if (animated && (replace || !current.visible)) await animate('entering');
    }
    current = next;
  }
  async function poll() {
    try {
      const query = new URLSearchParams({layer, channel, since: String(current.rev)});
      const response = await fetch(`api/output.php?${query}`, {cache: 'no-store', signal: AbortSignal.timeout(2500)});
      if (!response.ok) throw new Error('Output unavailable');
      const next = await response.json();
      if (!next.ok) throw new Error('Invalid response');
      if (!next.same) await apply(next);
      document.documentElement.dataset.connection = 'online';
    } catch (_) {
      // Keep the last rendered PROGRAM intact until a valid response is received.
      document.documentElement.dataset.connection = 'offline';
    } finally {
      setTimeout(poll, 300);
    }
  }
  setTimeout(poll, 300);
})();
