<?php
declare(strict_types=1);

function cg_instance(array $input): array
{
    $data = provider_load();
    $params = rwr_params($input, $data);
    $key = sha1(cg_json($params));
    $existing = cg_one('SELECT * FROM cg_instances WHERE template=? AND params_key=?', ['race-win-rate', $key]);
    if ($existing) {
        return $existing;
    }
    cg_query('INSERT INTO cg_instances(template,params_key,params_json,auto_json,auto_source,auto_at) VALUES (?,?,?,?,?,?)',
        ['race-win-rate', $key, cg_json($params), cg_json(rwr_build_auto($params, $data)), 'mock', cg_now()]);
    return cg_one('SELECT * FROM cg_instances WHERE id=?', [(int) cg_db()->lastInsertId()]);
}

function cg_instance_label(array $instance): string
{
    $view = rwr_present(json_decode($instance['auto_json'], true, 512, JSON_THROW_ON_ERROR));
    return implode(' / ', array_column($view['cols'], 'head'));
}

function cg_channel(string $kind): array
{
    return cg_one('SELECT * FROM cg_channels WHERE layer=1 AND kind=?', [$kind]);
}

function cg_snapshot(array $instance, array $display): array
{
    if ($instance['auto_json'] === null) {
        throw new CgError('NOT_SENDABLE', '정상 데이터를 받은 뒤 송출할 수 있습니다.', 422);
    }
    $final = json_decode($instance['auto_json'], true, 512, JSON_THROW_ON_ERROR);
    $view = rwr_present($final);
    return ['template' => $instance['template'], 'params' => json_decode($instance['params_json'], true),
        'final' => $final, 'view' => $view, 'html' => cg_render($view), 'display' => $display, 'mock' => true];
}

function cg_output(string $kind, int $layer = 1): array
{
    if ($layer !== 1 || !in_array($kind, ['preview', 'program'], true)) {
        throw new CgError('VALIDATION', '레이어 1과 preview/program 채널만 지원합니다.', 422);
    }
    $channel = cg_channel($kind);
    $snapshot = $channel['snapshot_json'] ? json_decode($channel['snapshot_json'], true, 512, JSON_THROW_ON_ERROR) : null;
    if ($kind === 'preview' && $channel['instance_id'] !== null) {
        $snapshot = cg_snapshot(cg_one('SELECT * FROM cg_instances WHERE id=?', [(int) $channel['instance_id']]),
            json_decode($channel['display_json'], true));
    }
    $page = $kind === 'preview' ? cg_one('SELECT page_no FROM cg_rundown WHERE id=?', [(int) cg_setting('preview_page_id')]) : null;
    return ['rev' => (int) $channel['rev'], 'take_id' => $channel['take_id'], 'visible' => (bool) $channel['visible'],
        'page_no' => $kind === 'preview' ? (int) ($page['page_no'] ?? 0) : ($snapshot['page_no'] ?? null),
        'instance_id' => $channel['instance_id'] === null ? null : (int) $channel['instance_id'],
        'html' => $snapshot['html'] ?? '', 'view' => $snapshot['view'] ?? null,
        'display' => $snapshot['display'] ?? json_decode($channel['display_json'], true),
        'mock' => $snapshot['mock'] ?? true, 'in' => $snapshot['in'] ?? 'cut'];
}

function cg_state(): array
{
    $session = (int) cg_setting('current_session_id');
    $pages = cg_query('SELECT r.id,r.page_no,r.label,r.instance_id,i.params_json
        FROM cg_rundown r JOIN cg_instances i ON i.id=r.instance_id WHERE r.session_id=? ORDER BY r.sort_order,r.id', [$session])->fetchAll();
    foreach ($pages as &$page) {
        $page['params'] = json_decode($page['params_json'], true);
        unset($page['params_json']);
    }
    unset($page);
    return ['rev' => (int) cg_setting('state_rev'), 'session' => cg_one('SELECT id,name,started_at FROM cg_sessions WHERE id=?', [$session]),
        'source' => cg_one('SELECT * FROM cg_sources WHERE id=?', ['mock']), 'pages' => $pages,
        'preview' => cg_output('preview'), 'program' => cg_output('program'),
        'logs' => cg_query('SELECT created_at,action,operator,detail FROM cg_logs ORDER BY id DESC LIMIT 30')->fetchAll()];
}

function cg_log(string $action, ?int $instance, string $detail): void
{
    cg_query('INSERT INTO cg_logs(created_at,action,operator,session_id,instance_id,detail) VALUES (?,?,?,?,?,?)',
        [cg_now(), $action, '로컬 운영자', (int) cg_setting('current_session_id'), $instance, $detail]);
}

function cg_int(array $input, string $key): int
{
    if (!isset($input[$key]) || !is_int($input[$key]) || $input[$key] < 0) {
        throw new CgError('VALIDATION', '요청의 ' . $key . ' 값이 유효하지 않습니다.', 422);
    }
    return $input[$key];
}

function cg_action(array $input): array
{
    return cg_transaction(static function () use ($input): array {
        $action = $input['action'] ?? '';
        $rev = (int) cg_setting('state_rev');
        if (cg_int($input, 'expected_rev') !== $rev) {
            throw new CgError('STATE_CHANGED', '다른 조작으로 상태가 바뀌었습니다. 화면을 확인한 뒤 다시 실행해 주세요.', 409);
        }
        $newRev = $rev + 1;
        $preview = cg_channel('preview');
        $program = cg_channel('program');
        $session = (int) cg_setting('current_session_id');
        $instance = $preview['instance_id'] === null ? null : (int) $preview['instance_id'];
        $detail = '';
        switch ($action) {
            case 'page_add':
                if (!is_array($input['params'] ?? null)) {
                    throw new CgError('VALIDATION', '페이지의 선수와 종족이 필요합니다.', 422);
                }
                $added = cg_instance($input['params']);
                $last = cg_one('SELECT MAX(page_no) AS n,MAX(sort_order) AS s FROM cg_rundown WHERE session_id=?', [$session]);
                $number = (int) $last['n'] + 1;
                if ($number > 999) {
                    throw new CgError('VALIDATION', '페이지는 최대 999개까지 만들 수 있습니다.', 422);
                }
                $detail = cg_instance_label($added);
                cg_query('INSERT INTO cg_rundown(session_id,page_no,instance_id,sort_order,label) VALUES (?,?,?,?,?)',
                    [$session, $number, $added['id'], (int) $last['s'] + 1, $detail]);
                $instance = (int) $added['id'];
                cg_query('UPDATE cg_settings SET v=? WHERE k=?', [(string) cg_db()->lastInsertId(), 'preview_page_id']);
                cg_query('UPDATE cg_channels SET instance_id=?,visible=1,rev=? WHERE layer=1 AND kind=?', [$instance, $newRev, 'preview']);
                break;
            case 'cue_page':
            case 'next':
                $pages = cg_query('SELECT * FROM cg_rundown WHERE session_id=? ORDER BY sort_order,id', [$session])->fetchAll();
                $page = null;
                if ($action === 'next') {
                    $current = 0;
                    foreach ($pages as $i => $row) {
                        if ((int) $row['id'] === (int) cg_setting('preview_page_id')) {
                            $current = $i;
                            break;
                        }
                    }
                    $page = $pages[($current + 1) % count($pages)];
                } else {
                    $number = cg_int($input, 'page_no');
                    foreach ($pages as $row) {
                        if ((int) $row['page_no'] === $number) {
                            $page = $row;
                            break;
                        }
                    }
                }
                if ($page === null) {
                    throw new CgError('VALIDATION', '해당 페이지 번호가 없습니다.', 422);
                }
                $instance = (int) $page['instance_id'];
                cg_query('UPDATE cg_settings SET v=? WHERE k=?', [(string) $page['id'], 'preview_page_id']);
                cg_query('UPDATE cg_channels SET instance_id=?,visible=1,rev=? WHERE layer=1 AND kind=?', [$instance, $newRev, 'preview']);
                $detail = sprintf('%03d · %s', $page['page_no'], $page['label']);
                break;
            case 'take':
                if (cg_int($input, 'expected_preview_rev') !== (int) $preview['rev']) {
                    throw new CgError('PREVIEW_CHANGED', 'PREVIEW가 바뀌었습니다. 확인 후 TAKE해 주세요.', 409);
                }
                if ($instance === null) {
                    throw new CgError('NOT_SENDABLE', '먼저 페이지를 PREVIEW에 올려 주세요.', 422);
                }
                $in = $input['in'] ?? 'anim';
                if (!in_array($in, ['anim', 'cut'], true)) {
                    throw new CgError('VALIDATION', '전환 방식을 확인해 주세요.', 422);
                }
                $snapshot = cg_snapshot(cg_one('SELECT * FROM cg_instances WHERE id=?', [$instance]), json_decode($preview['display_json'], true));
                $snapshot['in'] = $in;
                $snapshot['page_no'] = (int) cg_one('SELECT page_no FROM cg_rundown WHERE id=?', [(int) cg_setting('preview_page_id')])['page_no'];
                cg_query('UPDATE cg_channels SET instance_id=?,snapshot_json=?,visible=1,take_id=?,rev=? WHERE layer=1 AND kind=?',
                    [$instance, cg_json($snapshot), bin2hex(random_bytes(12)), $newRev, 'program']);
                $detail = implode(' / ', array_column($snapshot['view']['cols'], 'head')) . ' · ' . ($in === 'anim' ? '애니메이션' : 'CUT');
                break;
            case 'show':
            case 'out':
                if ($program['snapshot_json'] === null) {
                    throw new CgError('PROGRAM_EMPTY', '먼저 TAKE로 송출 화면을 준비해 주세요.', 409);
                }
                $instance = (int) $program['instance_id'];
                cg_query('UPDATE cg_channels SET visible=?,rev=? WHERE layer=1 AND kind=?', [$action === 'show' ? 1 : 0, $newRev, 'program']);
                $detail = $action === 'show' ? '현재 PROGRAM 표시' : '현재 PROGRAM 숨김';
                break;
            default:
                throw new CgError('VALIDATION', '지원하지 않는 조작입니다.', 422);
        }
        cg_query('UPDATE cg_settings SET v=? WHERE k=?', [(string) $newRev, 'state_rev']);
        cg_log(strtoupper($action), $instance, $detail);
        return cg_state();
    });
}
