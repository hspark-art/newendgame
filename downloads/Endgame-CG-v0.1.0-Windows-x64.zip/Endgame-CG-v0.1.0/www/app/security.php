<?php
declare(strict_types=1);

function cg_local(string $address): bool
{
    return $address === '127.0.0.1' || $address === '::1' || $address === '::ffff:127.0.0.1';
}

function cg_host_allowed(string $header, string $port, array $extra = []): bool
{
    if (!preg_match('/^(localhost|127\.0\.0\.1|\[::1\]|[a-z0-9.-]+)(?::([0-9]{1,5}))?$/iD', $header, $match)) {
        return false;
    }
    $host = strtolower($match[1]);
    $givenPort = $match[2] ?? '80';
    return $givenPort === $port && in_array($host, array_merge(['localhost', '127.0.0.1', '[::1]'], $extra), true);
}

function cg_require_host(): void
{
    $extra = array_filter(array_map('trim', explode(',', strtolower(getenv('CG_ALLOWED_HOSTS') ?: ''))));
    if (!cg_host_allowed($_SERVER['HTTP_HOST'] ?? '', (string) ($_SERVER['SERVER_PORT'] ?? '3100'), $extra)) {
        http_response_code(403);
        exit('허용되지 않은 Host입니다.');
    }
}

function cg_require_local(): void
{
    if (!cg_local($_SERVER['REMOTE_ADDR'] ?? '')) {
        http_response_code(403);
        exit('운영 패널은 서버 PC에서만 사용할 수 있습니다.');
    }
}

function cg_origin_allowed(string $origin, string $host): bool
{
    return $origin === 'http://' . $host;
}

function cg_public_path(string $uri): ?string
{
    $raw = explode('?', $uri, 2)[0];
    $path = rawurldecode($raw);
    $allowed = ['/' => 'index.php', '/index.php' => 'index.php', '/output.php' => 'output.php',
        '/api/ping.php' => 'api/ping.php', '/api/state.php' => 'api/state.php',
        '/api/output.php' => 'api/output.php', '/api/action.php' => 'api/action.php',
        '/assets/panel.css' => 'assets/panel.css', '/assets/panel.js' => 'assets/panel.js',
        '/assets/cg.css' => 'assets/cg.css', '/assets/output.css' => 'assets/output.css',
        '/assets/output.js' => 'assets/output.js'];
    // Encoded alternate paths are rejected rather than normalized into public routes.
    return $raw === $path ? ($allowed[$path] ?? null) : null;
}
