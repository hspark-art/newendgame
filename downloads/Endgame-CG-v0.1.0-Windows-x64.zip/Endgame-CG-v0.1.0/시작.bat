@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "CG_PHP=%~dp0runtime\php\php.exe"
if not exist "%CG_PHP%" (
  echo 처음 실행 준비: 공식 PHP를 내려받고 무결성을 확인합니다.
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0runtime\setup-php.ps1"
  if errorlevel 1 (
    echo 준비에 실패했습니다. WINDOWS-사용안내.txt를 확인하세요.
    pause
    exit /b 1
  )
)
"%CG_PHP%" -c "%~dp0runtime\php.ini" -d "extension_dir=%~dp0runtime\php\ext" "%~dp0runtime\start.php"
set "CG_RESULT=%ERRORLEVEL%"
if not "%CG_RESULT%"=="0" pause
exit /b %CG_RESULT%
