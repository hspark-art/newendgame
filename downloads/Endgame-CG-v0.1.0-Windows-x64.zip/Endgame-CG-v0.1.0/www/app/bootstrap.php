<?php
declare(strict_types=1);

const CG_VERSION = '0.1.0';
date_default_timezone_set('Asia/Seoul');

final class CgError extends RuntimeException
{
    public function __construct(public readonly string $errorCode, string $message, public readonly int $status)
    {
        parent::__construct($message);
    }
}

function cg_json(mixed $value): string
{
    return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR);
}

function cg_now(): string
{
    return date('Y-m-d H:i:s');
}

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/stats.php';
require_once __DIR__ . '/provider.php';
require_once __DIR__ . '/templates.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/control.php';

function cg_headers(): void
{
    cg_require_host();
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'; object-src 'none'");
    header('Referrer-Policy: same-origin');
}

function cg_session(): void
{
    cg_require_local();
    $path = __DIR__ . '/storage/sessions';
    if (!is_dir($path) && !mkdir($path, 0700, true) && !is_dir($path)) {
        throw new RuntimeException('세션 저장 폴더를 만들지 못했습니다.');
    }
    session_save_path($path);
    session_name('ENDGAME_CG');
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict', 'path' => '/']);
    session_start();
}

function cg_csrf(): string
{
    return hash_hmac('sha256', 'control:' . session_id(), cg_setting('csrf_secret'));
}

function cg_api(callable $action): never
{
    cg_headers();
    header('Content-Type: application/json; charset=utf-8');
    try {
        echo cg_json(['ok' => true] + $action());
    } catch (CgError $error) {
        http_response_code($error->status);
        echo cg_json(['ok' => false, 'code' => $error->errorCode, 'error' => $error->getMessage()]);
    } catch (Throwable $error) {
        error_log('CG request failed: ' . get_class($error));
        http_response_code(500);
        echo cg_json(['ok' => false, 'code' => 'SERVER_ERROR', 'error' => '요청을 처리하지 못했습니다. 서버 로그를 확인해 주세요.']);
    }
    exit;
}

function cg_output_request(): array
{
    $layer = $_GET['layer'] ?? '1';
    $kind = $_GET['channel'] ?? 'program';
    if (!is_string($layer) || $layer !== '1' || !is_string($kind)) {
        throw new CgError('VALIDATION', '출력 주소의 레이어와 채널을 확인해 주세요.', 422);
    }
    return cg_read(static fn() => cg_output($kind, 1));
}
