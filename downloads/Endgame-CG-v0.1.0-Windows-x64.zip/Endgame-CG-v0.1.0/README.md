# 끝장전 CG 기본 시스템

상대 종족 승률 CG 한 종류를 위한 로컬 운영 도구입니다. **현재 모든 기록은 MOCK이며 실제 전적이 아닙니다.** 기존 저장소의 채팅·상품 관리 프로그램(`../www/`)과 별도로 동작합니다.

## 현재 가능한 작업

- 선수·상대 종족을 선택해 페이지 추가
- 페이지 번호 + Enter 또는 페이지 더블클릭으로 PREVIEW 큐
- TAKE로 PREVIEW를 PROGRAM에 고정해서 송출
- OUT으로 숨기고 SHOW로 동일한 화면 다시 표시
- NEXT와 키보드 조작, 운영 기록, 서버 재시작 후 상태 복원
- 1920×1080 투명 출력, 우측 하단 560×250 CG, 애니메이션/CUT 전환

MOCK 기대값은 조일장 vs P 33승 21패(61.1%), 장윤철 vs Z 129승 123패(51.2%)입니다. 실제 선수 이름은 레퍼런스 표시 예시이며 경기 상대와 기록은 가상입니다. 조일장 vs T는 0경기로 “자료 없음”입니다. 상대 종족 승률의 집계 단위는 세트(개별 게임)의 승·패 합계로 확정했습니다. 다른 CG의 기준은 개별 확인합니다.

## Windows 실행

1. 저장소를 쓰기 가능한 폴더에 풉니다. 예: `C:\newendgame`. OneDrive 경로는 피하는 것을 권장합니다.
2. `cg/시작.bat` 또는 `cg/Start-CG.bat`를 더블클릭합니다. PHP가 없으면 Windows PowerShell이 공식 PHP x64 NTS를 내려받아 **공식 SHA-256이 존재하고 일치할 때만** 설치합니다. 첫 실행은 인터넷이 필요합니다.
3. Microsoft Visual C++ 재배포 패키지가 없으면 Microsoft 공식 설치 파일의 Authenticode 서명을 확인한 뒤 설치합니다. Windows가 관리자 권한 승인을 요청할 수 있습니다.
4. 필요한 확장, 포트, 서버 준비를 확인한 다음 Edge 앱 창을 엽니다. 기존 `runtime/php/` 파일은 임의로 덮어쓰거나 지우지 않습니다.
5. 처음에는 기본 MOCK 페이지가 준비됩니다. 새 페이지를 추가해 송출 흐름을 연습하세요.

실제 전적은 자동으로 내려받지 않습니다. `.bat`는 UTF-8 BOM 없음/CRLF이며 `chcp 65001`로 실행합니다. 실행기 창을 닫으면 서버가 종료됩니다. 같은 CG 서버가 이미 실행 중이면 새 서버를 만들지 않습니다. Windows에서 실제 자동 설치·Edge 실행은 아직 미검증입니다.

자동 설치를 사용할 수 없는 환경에서는 [PHP 공식 Windows 배포처](https://windows.php.net/download/)의 PHP 8.1 이상 x64 Non Thread Safe ZIP을 체크섬 확인 후 `cg/runtime/php/`에 풉니다. `php.exe`와 `ext/`가 그 폴더에 있어야 합니다. Microsoft 런타임은 PHP 공식 안내를 따릅니다.

## 다운로드 패키지 만들기

개발 환경에서 PHP zip 확장이 준비되면 `cg/`에서 `php build.php`를 실행합니다. `dist/Endgame-CG-v0.1.0-Windows-x64.zip`과 SHA-256 파일을 만듭니다. ZIP에는 프로그램·MOCK·첫 실행 설치 도구를 담고, 포터블 PHP는 사용자 PC의 첫 실행 때 다운로드합니다. 기존 운영 DB·세션·로그·개인 config·실제 원본 자료는 포함하지 않습니다.

## PHP가 설치된 개발 환경

PHP 8.1 이상과 `pdo_sqlite`, `mbstring`, `openssl`이 필요합니다. Composer와 프런트엔드 빌드는 없습니다. **`cg/` 디렉터리에서** 실행합니다.

```sh
php -S 127.0.0.1:3100 -t www router.php
```

운영 패널은 서버 PC의 브라우저에서 `http://127.0.0.1:3100/`를 입력해 엽니다. 이 주소는 사용자 PC에서 실행한 서버의 주소입니다. 클라우드 온보딩 화면에는 localhost 미리보기 링크를 제공하지 않습니다.

클라우드의 작업 공간 런타임을 사용하는 경우:

```sh
export PATH=/workspace/shared/cg-tools/bin:$PATH
cd /workspace/newendgame/cg
php -S 127.0.0.1:3100 -t www router.php
```

## 기본 송출 순서

1. 페이지 추가에서 왼쪽·오른쪽 선수와 각 상대 종족을 선택합니다. 추가된 페이지는 PREVIEW에 올라갑니다.
2. 기존 페이지는 번호를 입력하고 Enter를 누르거나, 목록에서 더블클릭합니다.
3. PREVIEW를 확인하고 TAKE를 누릅니다. PROGRAM은 이 시점의 데이터·표시 내용을 저장합니다.
4. 다른 페이지를 PREVIEW에 올려도 PROGRAM은 유지됩니다.
5. OUT으로 화면을 숨기고 SHOW로 마지막 PROGRAM을 다시 표시합니다.

단축키는 F1/Space TAKE, F2 OUT, F3 SHOW, F4 NEXT, ↑↓ 페이지 선택, Enter 큐입니다. 입력칸과 추가 대화상자에서는 전역 단축키를 실행하지 않습니다. 조작이 충돌하면 자동 재전송하지 않고 상태 확인을 안내합니다.

## OBS / vMix 등록

CG 서버와 OBS/vMix가 **같은 PC**일 때 브라우저 소스에 `http://127.0.0.1:3100/output.php?layer=1`을 등록하고 크기를 **1920×1080**으로 설정합니다. 운영 패널의 출력 주소 복사 버튼을 사용할 수 있습니다. 출력 페이지는 처음 열 때 저장된 PROGRAM을 바로 그립니다. 서버 연결이 끊겨도 이미 열린 출력은 마지막 화면을 유지합니다.

출력 페이지 밖 배경은 투명하며, 패널 모니터에서만 체커보드로 표현합니다. 기본 폰트는 맑은 고딕이고 실제 방송 폰트는 미확정입니다.

다른 PC에서 받는 LAN 실행기·방화벽 설정은 이번 기본 시스템의 제공 범위에 넣지 않았습니다. 향후 LAN 실행 시 실제 IP를 `CG_ALLOWED_HOSTS`에 명시하고 출력만 외부에서 읽도록 구성해야 합니다. 원격 운영·공개 웹호스팅에는 별도 인증 설계가 필요합니다. 현재 서버는 로컬 개발·운영용입니다.

## 자료 보관

상태·로그·세션은 Git에서 제외된 `www/app/storage/`에 보관됩니다. 서버를 종료한 뒤 폴더 전체를 복사해 백업합니다. 앱 재시작은 새 방송 세션을 만들지 않습니다. 코드 업데이트 시 저장 폴더를 덮어쓰지 마세요.

개발 테스트는 `CG_DB_PATH`로 임시 SQLite 경로를 지정할 수 있습니다. 선택 설정은 `www/app/config.sample.php`를 `config.php`로 복사해 사용합니다. 로컬 설정과 키는 버전 관리에서 제외합니다.

## 검증

`cg/`에서 실행합니다. 두 러너 모두 임시 DB를 사용하므로 운영 자료를 변경하지 않습니다.

```sh
php tests/run.php
php tests/http_smoke.php
```

순수 통계·MOCK 검증, 페이지별 상태, PROGRAM 고정, OUT/SHOW, 재시작, 트랜잭션 롤백, 경로·Host·Origin 차단을 검증합니다. HTTP 러너는 별도 임시 포트에 서버를 실행해 CSRF·JSON 형식·SSR·상태 리비전도 검증합니다.

Node.js·Playwright·Chromium이 이미 준비된 개발 환경에서는 선택적으로 `node tests/browser_smoke.js`를 실행할 수 있습니다. 이 도구들도 프로그램 실행에는 필요하지 않습니다. `CG_PHP_EXEC`, `CG_BROWSER_EXEC`로 실행 파일을 지정하고 `CG_ARTIFACTS_DIR`로 캡처 저장 위치를 지정할 수 있습니다. 기본 캡처는 Git에서 제외된 `tests/artifacts/`에 저장합니다. 검증 결과와 한계는 `docs/VALIDATION.md`에 기록했습니다.

Windows 더블클릭, Edge 실행, 실제 OBS/vMix 송출과 실제 방송 데이터는 해당 환경에서 검수 전까지 **미검증**입니다. 클라우드 Linux의 테스트 통과를 실제 방송 검수로 대신하지 않습니다.

## 다음 검토 대상

수동 수정(AUTO/MANUAL/FINAL), RESET/KEEP/UPDATE LIVE, 새 방송 세션, 페이지 복제·삭제·순서 변경, 배치 조정, 외부 데이터 연결, MySQL 구현은 아직 제공하지 않습니다. 기본 흐름을 검토한 뒤 다음 구현 범위를 정합니다.

실제 자료는 사용자 지정 끝장전 Google Sheets를 우선 사용하고 eloboard의 온라인 수치는 별도 보조 자료로 검토합니다. 지정 시트 탭의 조회용 CSV와 eloboard 공개 페이지·이용약관을 읽었지만, 경기 원본과 집계 수치는 아직 검증하지 않았습니다. `docs/DATA_SOURCES.md`에 주소·접근 결과·정확성·최소 수집·검증 원칙을 정리했으며 앱은 계속 MOCK 전용입니다. 완성 후 제공할 PC용 앱과 PHP 웹 패키지의 요구사항은 `docs/DELIVERY.md`에 기록했습니다.
