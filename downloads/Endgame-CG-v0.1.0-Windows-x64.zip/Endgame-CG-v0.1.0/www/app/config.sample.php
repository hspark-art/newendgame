<?php
// Optional local configuration. Copy to config.php; do not commit that file.
return ['db_path' => __DIR__ . '/storage/cg.sqlite'];
