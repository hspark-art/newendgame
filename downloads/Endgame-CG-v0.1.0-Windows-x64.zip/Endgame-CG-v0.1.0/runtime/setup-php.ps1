$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Downloads are verified before extraction/execution. No user data is removed.
$runtime = $PSScriptRoot
$destination = Join-Path $runtime 'php'
$temporary = Join-Path ([IO.Path]::GetTempPath()) ('endgame-cg-' + [Guid]::NewGuid().ToString('N'))
$stage = Join-Path $runtime ('php-install-' + [Guid]::NewGuid().ToString('N'))
$createdStage = $false
$result = 1
$lock = $null

try {
    $lock = [IO.File]::Open((Join-Path $runtime '.setup.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    if (-not [Environment]::Is64BitOperatingSystem) {
        throw 'This package requires 64-bit Windows.'
    }
    if (Test-Path -LiteralPath (Join-Path $destination 'php.exe')) {
        Write-Host 'Portable PHP is already present.'
        exit 0
    }
    if (Test-Path -LiteralPath $destination) {
        throw 'runtime\php already exists but is incomplete. Move it aside manually before retrying. Existing files were preserved.'
    }
    New-Item -ItemType Directory -Path $temporary | Out-Null

    # PHP requires Microsoft VC++ runtime. Verify Authenticode before invoking its installer.
    $system = Join-Path $env:WINDIR 'System32'
    if (-not (Test-Path (Join-Path $system 'vcruntime140.dll')) -or
        -not (Test-Path (Join-Path $system 'vcruntime140_1.dll'))) {
        Write-Host 'Microsoft Visual C++ runtime is required. Windows may ask for administrator approval.'
        $vc = Join-Path $temporary 'vc_redist.x64.exe'
        Invoke-WebRequest -Uri 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $vc -UseBasicParsing
        $signature = Get-AuthenticodeSignature -LiteralPath $vc
        if ($signature.Status -ne 'Valid' -or $null -eq $signature.SignerCertificate -or
            $signature.SignerCertificate.Subject -notmatch '(?:^|,\s*)O=Microsoft Corporation(?:,|$)') {
            throw 'Microsoft runtime signature verification failed. Installer was not executed.'
        }
        $install = Start-Process -FilePath $vc -ArgumentList '/install', '/passive', '/norestart' -Wait -PassThru
        if (@(0, 1638, 3010) -notcontains $install.ExitCode) {
            throw ('Microsoft runtime installation failed: ' + $install.ExitCode)
        }
    }

    Write-Host 'Reading official PHP Windows release metadata...'
    $releases = Invoke-RestMethod -Uri 'https://windows.php.net/downloads/releases/releases.json' -UseBasicParsing
    $archive = $null
    foreach ($branch in @('8.4', '8.3', '8.5')) {
        $info = $releases.$branch
        if ($null -eq $info) { continue }
        foreach ($build in $info.PSObject.Properties) {
            if ($build.Name -match '^nts-vs\d+-x64$' -and $null -ne $build.Value.zip) {
                $archive = $build.Value.zip
                break
            }
        }
        if ($null -ne $archive) { break }
    }
    if ($null -eq $archive) { throw 'No compatible official PHP x64 NTS release was found.' }
    $filename = [string] $archive.path
    $expected = [string] $archive.sha256
    if ($filename -notmatch '^php-8\.[345]\.\d+-nts-Win32-vs\d+-x64\.zip$' -or
        $expected -notmatch '^[A-Fa-f0-9]{64}$') {
        throw 'Official PHP filename or SHA-256 is missing or invalid. Installation stopped.'
    }
    $zip = Join-Path $temporary $filename
    Write-Host ('Downloading ' + $filename + ' ...')
    Invoke-WebRequest -Uri ('https://windows.php.net/downloads/releases/' + $filename) -OutFile $zip -UseBasicParsing
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash
    if ($actual -ne $expected) { throw 'PHP checksum mismatch. Download was not extracted or executed.' }

    New-Item -ItemType Directory -Path $stage | Out-Null
    $createdStage = $true
    Expand-Archive -LiteralPath $zip -DestinationPath $stage
    $php = Join-Path $stage 'php.exe'
    if (-not (Test-Path -LiteralPath $php)) { throw 'The verified PHP archive does not contain php.exe.' }
    $ini = Join-Path $runtime 'php.ini'
    $extensions = Join-Path $stage 'ext'
    & $php -c $ini -d ('extension_dir=' + $extensions) (Join-Path $runtime 'check.php')
    if ($LASTEXITCODE -ne 0) { throw 'PHP runtime or required extensions failed readiness checks.' }
    Move-Item -LiteralPath $stage -Destination $destination
    $createdStage = $false
    Write-Host 'Portable PHP is ready. Starting Endgame CG...'
    $result = 0
}
catch {
    Write-Host ('SETUP FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'See the included Windows guide. Do not disable certificate or checksum verification.'
}
finally {
    if ($createdStage -and (Test-Path -LiteralPath $stage)) {
        Remove-Item -LiteralPath $stage -Recurse -Force
    }
    if (Test-Path -LiteralPath $temporary) {
        Remove-Item -LiteralPath $temporary -Recurse -Force
    }
    if ($null -ne $lock) { $lock.Dispose() }
}
exit $result
