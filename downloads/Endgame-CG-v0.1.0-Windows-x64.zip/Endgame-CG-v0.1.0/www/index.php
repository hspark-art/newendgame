<?php
require_once __DIR__ . '/app/bootstrap.php';
cg_headers();
cg_require_local();
cg_session();
$state = cg_read(static fn() => cg_state());
$initial = ['state' => $state, 'csrf' => cg_csrf()];
session_write_close();
$players = array_filter(provider_load()['players'], static fn(array $p) => $p['selectable'] ?? false);
?>
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>끝장전 · CG CONTROL</title><link rel="stylesheet" href="assets/panel.css">
  <script src="assets/panel.js" defer></script>
</head>
<body>
<header class="topbar">
  <div class="brand"><span class="brand-mark">E<span>G</span></span><div><strong>끝장전</strong><span class="eyebrow">CG CONTROL / BASIC</span></div></div>
  <div class="session"><span class="tiny-label">SESSION</span><span id="session-name">MOCK 연습 세션</span><span class="badge mock">MOCK</span></div>
  <div class="top-status"><span id="connection" class="connection">● 연결 확인 중</span><time id="clock">--:--:--</time></div>
</header>
<div class="notice"><span>연습 데이터</span> 화면에 표시되는 기록은 실제 전적이 아닙니다. <span class="notice-unit">상대 종족 승률 · 세트(개별 게임) 기준</span></div>
<main class="workspace">
  <section class="rundown-area">
    <div class="section-heading"><div><span class="eyebrow">YOUR RUNDOWN</span><h1>송출 페이지</h1></div><button id="open-add" class="button light">＋ 페이지 추가</button></div>
    <div class="rundown card">
      <div class="cue-bar"><label for="page-number">PAGE</label><input id="page-number" inputmode="numeric" maxlength="3" placeholder="001" aria-label="큐에 올릴 페이지 번호"><button id="cue-number" class="button small">PREVIEW에 올리기 <kbd>↵</kbd></button><span id="page-count"></span></div>
      <div class="table-scroll"><table><thead><tr><th>No.</th><th>CG / 페이지 내용</th><th>데이터</th><th>송출 상태</th></tr></thead><tbody id="pages"></tbody></table></div>
      <div class="table-foot"><span>페이지를 더블클릭하면 PREVIEW에 올라갑니다.</span><span>↑ ↓ 선택 · Enter 큐</span></div>
    </div>
    <section class="details card">
      <div class="card-title"><span class="eyebrow">PREVIEW DETAILS</span><span class="badge auto">AUTO</span></div>
      <h2 id="preview-title">상대 종족 승률</h2>
      <div id="record-cards" class="record-cards"></div>
      <p class="helper">페이지를 바꿔도 현재 송출은 유지됩니다. 확인 후 <strong>TAKE</strong>를 눌러 반영하세요.</p>
    </section>
    <section class="logs card"><div class="card-title"><h2>운영 기록</h2><span class="tiny-label">최근 30건</span></div><div id="logs" class="log-list"></div></section>
  </section>
  <aside class="control-area">
    <section class="monitor card pvw"><div class="monitor-title"><strong><i></i> PREVIEW</strong><span id="pvw-label">다음 송출</span></div><div class="monitor-stage"><iframe title="PREVIEW 화면" src="output.php?layer=1&amp;channel=preview"></iframe></div></section>
    <section class="monitor card pgm"><div class="monitor-title"><strong><i></i> PROGRAM</strong><span id="pgm-label">OFF AIR</span></div><div class="monitor-stage"><iframe title="PROGRAM 화면" src="output.php?layer=1"></iframe><div id="empty-program" class="empty-program">송출 대기<span>PREVIEW를 확인하고 TAKE하세요.</span></div></div></section>
    <section class="transport card">
      <div class="transition"><label for="transition">전환</label><select id="transition"><option value="anim">애니메이션 · 350ms</option><option value="cut">CUT · 즉시 전환</option></select><span class="tiny-label">LAYER 01</span></div>
      <button class="button take" id="take">TAKE <span>PREVIEW → PROGRAM</span><kbd>F1 / Space</kbd></button>
      <div class="secondary-controls"><button id="out" class="button out">OUT <kbd>F2</kbd></button><button id="show" class="button">SHOW <kbd>F3</kbd></button><button id="next" class="button">NEXT <kbd>F4</kbd></button></div>
      <p class="helper">OUT은 화면을 숨기고, SHOW는 마지막 송출 화면을 다시 표시합니다.</p>
    </section>
    <section class="output-guide card"><h2>OBS / vMix 출력</h2><div class="output-address"><code id="output-path">output.php?layer=1</code><button id="copy-output" class="button small" aria-label="출력 주소 복사">복사</button></div><p class="helper">브라우저 소스 · 1920 × 1080 · 투명 배경</p></section>
  </aside>
</main>
<footer class="footer"><span>끝장전 CG <span class="muted">/ 상대 종족 승률</span></span><span>수동 수정 · 외부 데이터 연결은 다음 단계</span></footer>
<div id="toast" role="status" aria-live="polite" hidden></div>
<dialog id="add-dialog"><form id="add-form"><div class="dialog-header"><div><span class="eyebrow">NEW PAGE</span><h2>상대 종족 승률 페이지</h2></div><button type="button" id="close-add" class="icon-button" aria-label="닫기">×</button></div><p class="helper">두 선수와 각 선수의 상대 종족을 고르세요. 데이터는 MOCK입니다.</p><div class="dialog-cols">
<?php foreach (['a' => '왼쪽 선수', 'b' => '오른쪽 선수'] as $side => $label): ?>
<fieldset><legend><?= $label ?></legend><label>선수<select name="<?= $side ?>_id"><?php foreach ($players as $p): ?><option value="<?= cg_h($p['id']) ?>"<?= ($side === 'b' && $p['id'] === 'jangyooncheol') ? ' selected' : '' ?>><?= cg_h($p['name']) ?></option><?php endforeach; ?></select></label><label>상대 종족<select name="<?= $side ?>_race"><?php foreach (['P' => '프로토스 (P)', 'T' => '테란 (T)', 'Z' => '저그 (Z)'] as $race => $name): ?><option value="<?= $race ?>"<?= ($side === 'b' && $race === 'Z') ? ' selected' : '' ?>><?= $name ?></option><?php endforeach; ?></select></label></fieldset>
<?php endforeach; ?>
</div><div class="dialog-footer"><span class="helper">추가 후 PREVIEW에 올라갑니다.</span><button type="submit" class="button light">페이지 추가</button></div></form></dialog>
<script type="application/json" id="initial-state"><?= cg_json($initial) ?></script>
</body></html>
