<?php
declare(strict_types=1);
require_once __DIR__ . '/www/app/security.php';
cg_require_host();
$file = cg_public_path($_SERVER['REQUEST_URI'] ?? '');
if ($file === null) {
    http_response_code(403);
    exit('Forbidden');
}
if (in_array($file, ['index.php', 'api/state.php', 'api/action.php'], true)) {
    cg_require_local();
}
if (str_starts_with($file, 'assets/')) {
    header('Content-Type: ' . (str_ends_with($file, '.css') ? 'text/css' : 'application/javascript') . '; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    readfile(__DIR__ . '/www/' . $file);
    return true;
}
require __DIR__ . '/www/' . $file;
return true;
