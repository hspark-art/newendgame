<?php
declare(strict_types=1);

function stats_rate_tenths(int $wins, int $losses): ?int
{
    if ($wins < 0 || $losses < 0 || $wins > 10000000 || $losses > 10000000) {
        throw new InvalidArgumentException('승·패 값이 유효하지 않습니다.');
    }
    $games = $wins + $losses;
    return $games === 0 ? null : intdiv(2000 * $wins + $games, 2 * $games);
}

function stats_race_record(array $matches, string $playerId, string $vsRace): array
{
    $wins = $losses = 0;
    foreach ($matches as $match) {
        if ($match['a'] === $playerId && $match['b_race'] === $vsRace) {
            $wins += $match['a_score'];
            $losses += $match['b_score'];
        } elseif ($match['b'] === $playerId && $match['a_race'] === $vsRace) {
            $wins += $match['b_score'];
            $losses += $match['a_score'];
        }
    }
    return ['wins' => $wins, 'losses' => $losses, 'games' => $wins + $losses];
}
