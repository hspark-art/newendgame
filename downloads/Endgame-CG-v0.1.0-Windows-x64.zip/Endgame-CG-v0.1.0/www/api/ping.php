<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
cg_api(static function (): array {
    cg_db();
    return ['app' => 'endgame-cg', 'version' => CG_VERSION, 'ready' => true, 'mock' => true];
});
