<?php
declare(strict_types=1);

function cg_db(): PDO
{
    if (isset($GLOBALS['CG_DB'])) {
        return $GLOBALS['CG_DB'];
    }
    $configFile = __DIR__ . '/config.php';
    $config = is_file($configFile) ? require $configFile : [];
    $path = getenv('CG_DB_PATH') ?: ($config['db_path'] ?? __DIR__ . '/storage/cg.sqlite');
    if (!is_dir(dirname($path)) && !mkdir(dirname($path), 0700, true) && !is_dir(dirname($path))) {
        throw new RuntimeException('저장 폴더를 만들지 못했습니다.');
    }
    $db = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $db->exec('PRAGMA busy_timeout=5000');
    $db->exec('PRAGMA foreign_keys=ON');
    $db->exec('PRAGMA journal_mode=WAL');
    $GLOBALS['CG_DB'] = $db;
    cg_migrate($db);
    return $db;
}

function cg_query(string $sql, array $params = []): PDOStatement
{
    $query = cg_db()->prepare($sql);
    foreach (array_values($params) as $i => $value) {
        $query->bindValue($i + 1, $value, is_int($value) ? PDO::PARAM_INT : ($value === null ? PDO::PARAM_NULL : PDO::PARAM_STR));
    }
    $query->execute();
    return $query;
}

function cg_one(string $sql, array $params = []): ?array
{
    return cg_query($sql, $params)->fetch() ?: null;
}

function cg_setting(string $key): string
{
    return (string) (cg_one('SELECT v FROM cg_settings WHERE k=?', [$key])['v'] ?? '');
}

function cg_transaction(callable $action): mixed
{
    $db = cg_db();
    $db->exec('BEGIN IMMEDIATE');
    try {
        $result = $action();
        $db->exec('COMMIT');
        return $result;
    } catch (Throwable $error) {
        $db->exec('ROLLBACK');
        throw $error;
    }
}

function cg_read(callable $action): mixed
{
    $db = cg_db();
    $db->exec('BEGIN');
    try {
        $result = $action();
        $db->exec('COMMIT');
        return $result;
    } catch (Throwable $error) {
        $db->exec('ROLLBACK');
        throw $error;
    }
}

function cg_migrate(PDO $db): void
{
    if ($db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='cg_settings'")->fetchColumn()) {
        if (cg_setting('schema_version') !== '1') {
            throw new RuntimeException('지원하지 않는 CG 데이터베이스 버전입니다.');
        }
        return;
    }
    cg_transaction(static function () use ($db): void {
        // Another worker may have completed the initial migration while this one waited.
        if ($db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='cg_settings'")->fetchColumn()) {
            return;
        }
        $db->exec('CREATE TABLE cg_settings (k TEXT PRIMARY KEY, v TEXT NOT NULL);
            CREATE TABLE cg_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, started_at TEXT NOT NULL);
            CREATE TABLE cg_instances (id INTEGER PRIMARY KEY AUTOINCREMENT, template TEXT NOT NULL,
                params_key TEXT NOT NULL, params_json TEXT NOT NULL, auto_json TEXT, auto_source TEXT NOT NULL,
                auto_at TEXT NOT NULL, UNIQUE(template, params_key));
            CREATE TABLE cg_rundown (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL REFERENCES cg_sessions(id),
                page_no INTEGER NOT NULL, instance_id INTEGER NOT NULL REFERENCES cg_instances(id),
                sort_order INTEGER NOT NULL, label TEXT NOT NULL, UNIQUE(session_id,page_no));
            CREATE TABLE cg_channels (layer INTEGER NOT NULL, kind TEXT NOT NULL, instance_id INTEGER REFERENCES cg_instances(id),
                snapshot_json TEXT, display_json TEXT NOT NULL, visible INTEGER NOT NULL DEFAULT 0,
                take_id TEXT, rev INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(layer,kind));
            CREATE TABLE cg_sources (id TEXT PRIMARY KEY, status TEXT NOT NULL, last_success_at TEXT, last_error TEXT);
            CREATE TABLE cg_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, action TEXT NOT NULL,
                operator TEXT NOT NULL, session_id INTEGER NOT NULL, instance_id INTEGER, detail TEXT NOT NULL);');
        foreach (['schema_version' => '1', 'state_rev' => '1', 'csrf_secret' => bin2hex(random_bytes(32))] as $key => $value) {
            cg_query('INSERT INTO cg_settings(k,v) VALUES (?,?)', [$key, $value]);
        }
        cg_query('INSERT INTO cg_sessions(name,started_at) VALUES (?,?)', ['MOCK 연습 세션', cg_now()]);
        $session = (int) $db->lastInsertId();
        cg_query('INSERT INTO cg_settings(k,v) VALUES (?,?)', ['current_session_id', (string) $session]);
        cg_query('INSERT INTO cg_sources(id,status,last_success_at) VALUES (?,?,?)', ['mock', 'OK', cg_now()]);
        $instance = cg_instance(['a_id' => 'joiljang', 'a_race' => 'P', 'b_id' => 'jangyooncheol', 'b_race' => 'Z']);
        cg_query('INSERT INTO cg_rundown(session_id,page_no,instance_id,sort_order,label) VALUES (?,?,?,?,?)',
            [$session, 1, $instance['id'], 1, cg_instance_label($instance)]);
        cg_query('INSERT INTO cg_settings(k,v) VALUES (?,?)', ['preview_page_id', (string) $db->lastInsertId()]);
        foreach (['preview', 'program'] as $kind) {
            cg_query('INSERT INTO cg_channels(layer,kind,instance_id,display_json,visible,rev) VALUES (?,?,?,?,?,?)',
                [1, $kind, $kind === 'preview' ? $instance['id'] : null,
                    cg_json(['right' => 0, 'bottom' => 4, 'scale_pct' => 100]), $kind === 'preview' ? 1 : 0, 1]);
        }
        cg_log('INIT', $instance['id'], 'MOCK 데이터로 기본 시스템 준비');
    });
}
