<?php
declare(strict_types=1);
if (PHP_VERSION_ID < 80100) {
    fwrite(STDERR, "PHP 8.1 or newer is required.\n");
    exit(1);
}
foreach (['pdo_sqlite', 'mbstring', 'openssl'] as $extension) {
    if (!extension_loaded($extension)) {
        fwrite(STDERR, 'Missing PHP extension: ' . $extension . "\n");
        exit(1);
    }
}
echo 'PHP ' . PHP_VERSION . " and required extensions ready\n";
