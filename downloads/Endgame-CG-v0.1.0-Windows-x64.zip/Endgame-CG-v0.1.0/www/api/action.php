<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
cg_require_local();
cg_api(static function (): array {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        throw new CgError('METHOD', 'POST 요청만 허용됩니다.', 405);
    }
    if (!cg_origin_allowed($_SERVER['HTTP_ORIGIN'] ?? '', $_SERVER['HTTP_HOST'] ?? '')) {
        throw new CgError('ORIGIN', '요청 출처를 확인하지 못했습니다.', 403);
    }
    if (strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0])) !== 'application/json') {
        throw new CgError('CONTENT_TYPE', 'JSON 요청만 허용됩니다.', 415);
    }
    cg_session();
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(cg_csrf(), $token)) {
        throw new CgError('CSRF', '운영 패널을 새로고침한 뒤 다시 실행해 주세요.', 403);
    }
    session_write_close();
    $raw = file_get_contents('php://input', false, null, 0, 16385);
    if ($raw === false || strlen($raw) > 16384) {
        throw new CgError('VALIDATION', '요청이 너무 큽니다.', 413);
    }
    try {
        $input = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new CgError('VALIDATION', 'JSON 요청 형식이 올바르지 않습니다.', 422);
    }
    if (!is_array($input) || array_is_list($input)) {
        throw new CgError('VALIDATION', '요청 형식이 올바르지 않습니다.', 422);
    }
    return ['state' => cg_action($input)];
});
