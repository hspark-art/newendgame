@echo off
chcp 65001 >nul
call "%~dp0시작.bat"
exit /b %ERRORLEVEL%
