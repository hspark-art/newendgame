# 기본 시스템 검증 기록

대상: 끝장전 CG v0.1.0, 클라우드 Debian 13, PHP 8.4.26, 시스템 Chromium.

| 검증 | 결과 | 범위 |
|---|---|---|
| `php tests/run.php` | 50 통과 / 0 실패 | 통계·반올림·MOCK 검증·큐·고정본·롤백·재시작·경로/Host/Origin |
| `php tests/http_smoke.php` | 29 통과 / 0 실패 | 임시 서버의 실제 HTTP·CSRF·SSR·출력·상태 충돌 |
| `node tests/browser_smoke.js` | 17 통과 / 0 실패 | 추가·번호 큐·더블클릭·단축키·TAKE/CUT/애니메이션·OUT/SHOW·NEXT·중단/복구·좁은 화면 |
| 1920×1080 출력 캡처 | 통과 | CG 좌표 x=1360/y=826, 크기 560×250 |
| PNG 알파 채널 확인 | 통과 | CG 밖 alpha=0, CG 안 alpha=255, 아래 4px 투명 |
| PHP/JS 구문 확인 | 통과 | 구현 PHP·JS 파일 |
| Windows bat 파일 형식 | 통과 | UTF-8 BOM 없음, CRLF, `chcp 65001` |
| PHP 실행기 | Linux에서 통과 | 서버 준비 확인·기존 서버 재사용·기존 SQLite 보존 |
| 클라우드 설치 스크립트 재실행 | 통과 | APT 서명·체크섬 검증 유지, 작업 공간 PHP와 테스트 |

브라우저 검증은 임시 DB와 임시 서버를 사용했다. 실제 운영 DB에는 테스트 페이지·송출 기록을 넣지 않았다. 첫 더블클릭 검증에서 이벤트가 누락되는 문제를 찾아, 단일 클릭 시 행 DOM을 교체하지 않도록 수정한 후 다시 통과했다. 애니메이션은 MutationObserver로 OUT/IN 클래스 전환과 최종 표시 상태를 확인했다.

Playwright의 기본 브라우저는 설치되어 있지 않았고 CDN 다운로드는 환경 네트워크 정책에서 403으로 거부되었다. 기존 시스템 Chromium으로 검증을 완료했으며, 브라우저 다운로드를 위한 네트워크 정책 완화는 하지 않았다.

## 미검증·미구현

- Windows에서 bat/포터블 PHP/Edge 실제 실행과 종료
- OBS/vMix 실송출, LAN 접속과 방화벽
- 실제 방송 폰트·전적·집계 단위
- 수동 수정, RESET/KEEP/UPDATE LIVE, 새 세션, 외부 소스, MySQL

설치·시작 지침은 환경 설정의 `install_script`와 `start_skill` 초안에 저장했다. 저장은 현재 머신에서의 실행이나 환경 게시를 의미하지 않는다. 새 클라우드 작업에서의 복원·검증과 사용자 게시 작업은 아직 수행하지 않았다.
