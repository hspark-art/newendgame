'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const initial = JSON.parse($('initial-state').textContent);
  let state = initial.state;
  let csrf = initial.csrf;
  let selected = state.preview.page_no;
  let busy = false;
  let toastTimer;
  const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const number = n => String(n).padStart(3, '0');
  const messages = {take:'PREVIEW를 PROGRAM으로 송출했습니다.', out:'PROGRAM을 숨겼습니다.', show:'PROGRAM을 다시 표시했습니다.', next:'다음 페이지를 PREVIEW에 올렸습니다.', cue_page:'PREVIEW에 페이지를 올렸습니다.', page_add:'페이지를 추가하고 PREVIEW에 올렸습니다.'};
  function toast(message, error = false) {
    clearTimeout(toastTimer);
    $('toast').textContent = message;
    $('toast').classList.toggle('error', error);
    $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, error ? 7000 : 3000);
  }
  function connection(online) {
    $('connection').textContent = online ? '● 서버 연결됨' : '● 연결 끊김 · 마지막 화면 유지';
    $('connection').classList.toggle('offline', !online);
  }
  function buttons() {
    document.querySelectorAll('.transport button, #cue-number, #add-form button[type="submit"]').forEach(button => {button.disabled = busy;});
    $('out').disabled = busy || !state.program.take_id || !state.program.visible;
    $('show').disabled = busy || !state.program.take_id || state.program.visible;
    $('take').disabled = busy || !state.preview.view;
  }
  function render() {
    $('session-name').textContent = state.session.name;
    $('page-count').textContent = `${state.pages.length} PAGES`;
    $('pages').innerHTML = state.pages.map(page => {
      const pvw = page.page_no === state.preview.page_no;
      const pgm = page.page_no === state.program.page_no && state.program.visible;
      return `<tr class="page-row ${page.page_no === selected ? 'selected' : ''}" data-page="${page.page_no}" tabindex="0" aria-label="${number(page.page_no)} ${escape(page.label)}"><td>${number(page.page_no)}</td><td><span class="page-type">상대 종족 승률</span><span class="page-label">${escape(page.label)}</span></td><td><span class="badge auto">AUTO</span></td><td>${pgm ? '<span class="air-tag">● ON AIR</span>' : ''}${pvw ? '<span class="preview-tag"> PREVIEW</span>' : ''}${!pvw && !pgm ? '<span class="muted">대기</span>' : ''}</td></tr>`;
    }).join('');
    const view = state.preview.view;
    $('preview-title').textContent = view?.title || 'PREVIEW 대기';
    $('record-cards').innerHTML = (view?.cols || []).map(col => `<div class="record-card"><span class="name">${escape(col.head)}</span><span class="record">${escape(col.record)}</span><span class="rate">${escape(col.rate)}</span></div>`).join('');
    $('pvw-label').textContent = `PAGE ${number(state.preview.page_no || 0)} · 다음 송출`;
    $('pgm-label').textContent = state.program.visible ? `● ON AIR · PAGE ${number(state.program.page_no)}` : (state.program.take_id ? 'OFF AIR · 화면 보관 중' : 'OFF AIR');
    $('pgm-label').style.color = state.program.visible ? '#fb686b' : '';
    $('empty-program').hidden = state.program.visible;
    const empty = $('empty-program');
    empty.firstChild.textContent = state.program.take_id ? '송출 화면 숨김' : '송출 대기';
    empty.querySelector('span').textContent = state.program.take_id ? 'SHOW를 누르면 마지막 화면이 표시됩니다.' : 'PREVIEW를 확인하고 TAKE하세요.';
    $('logs').innerHTML = state.logs.map(log => `<div class="log-row"><span class="log-time">${escape(log.created_at.slice(11))}</span><span class="log-action">${escape(log.action)}</span><span class="log-detail" title="${escape(log.detail)}">${escape(log.detail)}</span></div>`).join('');
    buttons();
  }
  function accept(next) {
    if (next.rev < state.rev) return;
    const changed = next.preview.page_no !== state.preview.page_no;
    state = next;
    if (changed) selected = state.preview.page_no;
    render();
  }
  async function refresh() {
    const response = await fetch(`api/state.php?since=${state.rev}`, {cache:'no-store', signal:AbortSignal.timeout(3000)});
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || '서버 응답 오류');
    csrf = data.csrf;
    if (!data.same) accept(data.state);
    connection(true);
  }
  async function action(actionName, extra = {}) {
    if (busy) return false;
    busy = true;
    buttons();
    try {
      const response = await fetch('api/action.php', {method:'POST', headers:{'Content-Type':'application/json','X-CSRF-Token':csrf}, body:JSON.stringify({action:actionName, expected_rev:state.rev,...extra}), signal:AbortSignal.timeout(5000)});
      const data = await response.json();
      if (!response.ok || !data.ok) {
        if (response.status === 409) await refresh();
        throw new Error(data.error || '조작을 완료하지 못했습니다.');
      }
      accept(data.state);
      connection(true);
      toast(messages[actionName]);
      return true;
    } catch (error) {
      toast(error.name === 'TimeoutError' || error.name === 'TypeError' ? '응답을 확인하지 못했습니다. 연결 복구 후 운영 기록을 확인하세요. 같은 조작을 자동 재전송하지 않습니다.' : error.message, true);
      return false;
    } finally {
      busy = false;
      buttons();
    }
  }
  async function poll() {
    try { await refresh(); } catch (_) { connection(false); }
    setTimeout(poll, 1000);
  }
  const cue = page => action('cue_page', {page_no:page});
  function cueNumber() {
    const raw = $('page-number').value.trim();
    if (!/^\d{1,3}$/.test(raw) || Number(raw) === 0) { toast('001~999의 페이지 번호를 입력해 주세요.', true); return; }
    cue(Number(raw));
  }
  $('cue-number').addEventListener('click', cueNumber);
  $('page-number').addEventListener('keydown', event => {if (event.key === 'Enter') {event.preventDefault(); cueNumber();}});
  $('pages').addEventListener('click', event => {
    const row = event.target.closest('[data-page]');
    if (!row) return;
    selected = Number(row.dataset.page);
    // Preserve the clicked DOM node so the browser can deliver a second click/dblclick.
    $('pages').querySelectorAll('[data-page]').forEach(item => item.classList.toggle('selected', Number(item.dataset.page) === selected));
  });
  $('pages').addEventListener('dblclick', event => {const row = event.target.closest('[data-page]'); if (row) cue(Number(row.dataset.page));});
  const take = () => action('take', {expected_preview_rev:state.preview.rev, in:$('transition').value});
  $('take').addEventListener('click', take);
  for (const name of ['out','show','next']) $(name).addEventListener('click', () => action(name));
  const dialog = $('add-dialog');
  $('open-add').addEventListener('click', () => dialog.showModal());
  $('close-add').addEventListener('click', () => dialog.close());
  $('add-form').addEventListener('submit', async event => {
    event.preventDefault();
    const params = Object.fromEntries(new FormData(event.currentTarget));
    if (await action('page_add', {params})) dialog.close();
  });
  const outputURL = new URL('output.php?layer=1', location.href).href;
  // Keep the full browser-source address available for copying; the UI shows its route.
  $('copy-output').addEventListener('click', async () => {
    try {await navigator.clipboard.writeText(outputURL); toast('출력 주소를 복사했습니다.');}
    catch (_) {toast('주소 복사를 지원하지 않는 환경입니다. README의 출력 등록 안내를 확인하세요.',true);}
  });
  document.addEventListener('keydown', event => {
    if (event.repeat || event.ctrlKey || event.altKey || event.metaKey || dialog.open
        || event.target.closest('input,textarea,select,[contenteditable="true"]')) return;
    if (['Enter', ' '].includes(event.key) && event.target.closest('button,a')) return;
    if (['ArrowDown','ArrowUp'].includes(event.key)) {
      event.preventDefault();
      const i = Math.max(0, state.pages.findIndex(page => page.page_no === selected));
      selected = state.pages[(i + (event.key === 'ArrowDown' ? 1 : -1) + state.pages.length) % state.pages.length].page_no;
      render();
      return;
    }
    const commands = {F1:take, ' ':take, F2:()=>action('out'), F3:()=>action('show'), F4:()=>action('next'), Enter:()=>cue(selected)};
    if (commands[event.key]) {event.preventDefault(); commands[event.key]();}
  });
  const resize = new ResizeObserver(entries => {
    for (const entry of entries) entry.target.querySelector('iframe').style.transform = `scale(${entry.target.clientWidth / 1920})`;
  });
  document.querySelectorAll('.monitor-stage').forEach(stage => resize.observe(stage));
  function tick() {$('clock').textContent = new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date());}
  tick(); setInterval(tick,1000);
  render(); connection(true); setTimeout(poll,1000);
})();
