<?php
declare(strict_types=1);

chdir(dirname(__DIR__));
if (PHP_VERSION_ID < 80100) {
    fwrite(STDERR,"PHP 8.1 이상이 필요합니다.\n");exit(1);
}
foreach (['pdo_sqlite','mbstring','openssl'] as $extension) {
    if (!extension_loaded($extension)) {
        fwrite(STDERR,'필요한 PHP 확장이 없습니다: '.$extension."\n");exit(1);
    }
}
$url='http://127.0.0.1:3100/';
function ready(): bool
{
    $context=stream_context_create(['http'=>['timeout'=>1,'ignore_errors'=>true]]);
    $response=@file_get_contents('http://127.0.0.1:3100/api/ping.php',false,$context);
    $ping=$response!==false?json_decode($response,true):null;
    return ($ping['app']??'')==='endgame-cg'&&($ping['ready']??false)===true;
}
function open_panel(string $url):void
{
    if(getenv('CG_NO_BROWSER')||PHP_OS_FAMILY!=='Windows')return;
    foreach(['ProgramFiles(x86)','ProgramFiles','LOCALAPPDATA'] as $name){
        $path=getenv($name);
        if(!$path)continue;
        $edge=$path.'\\Microsoft\\Edge\\Application\\msedge.exe';
        if(is_file($edge)){
            // Paths come from the OS; escape shell metacharacters before using cmd's start.
            if(strpbrk($edge,'"%&|<>^')!==false)continue;
            pclose(popen('start "" "'.$edge.'" --app='.$url.' --window-size=1920,1080','r'));
            return;
        }
    }
    pclose(popen('start "" '.$url,'r'));
}
if(ready()){
    echo "이미 실행 중입니다. 기존 운영 패널을 엽니다.\n";open_panel($url);exit(0);
}
$socket=@fsockopen('127.0.0.1',3100,$errno,$error,0.5);
if($socket){fclose($socket);fwrite(STDERR,"3100 포트를 다른 프로그램이 사용 중입니다. 서버 로그를 확인해 주세요.\n");exit(1);}
$storage='www/app/storage';
if(!is_dir($storage)&&!mkdir($storage,0700,true)&&!is_dir($storage)){
    fwrite(STDERR,"저장 폴더를 만들지 못했습니다. 폴더의 쓰기 권한을 확인해 주세요.\n");exit(1);
}
$command=[PHP_BINARY];
if(php_ini_loaded_file())array_push($command,'-c',php_ini_loaded_file());
array_push($command,'-d','extension_dir='.ini_get('extension_dir'),'-S','127.0.0.1:3100','-t','www','router.php');
$process=proc_open($command,[0=>['pipe','r'],1=>['file',$storage.'/server.log','a'],2=>['file',$storage.'/server.log','a']],$pipes);
if(!is_resource($process)){fwrite(STDERR,"서버를 시작하지 못했습니다.\n");exit(1);}
fclose($pipes[0]);
register_shutdown_function(static function()use($process):void{if(is_resource($process)){proc_terminate($process);proc_close($process);}});
$started=false;
for($i=0;$i<40;$i++){
    if(ready()){$started=true;break;}
    if(!proc_get_status($process)['running'])break;
    usleep(100000);
}
if(!$started){fwrite(STDERR,"서버가 준비되지 않았습니다. www/app/storage/server.log를 확인해 주세요.\n");exit(1);}
echo "끝장전 CG 기본 시스템 실행 중 (MOCK)\n";
echo '운영 패널: '.$url."\n";
echo "이 창을 닫으면 서버가 종료됩니다. 자료는 www/app/storage에 보관됩니다.\n";
open_panel($url);
while(proc_get_status($process)['running'])sleep(1);
fwrite(STDERR,"서버가 종료되었습니다.\n");exit(1);
