<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
cg_require_local();
cg_api(static function (): array {
    cg_session();
    $state = cg_read(static fn() => cg_state());
    $csrf = cg_csrf();
    session_write_close();
    if (isset($_GET['since']) && is_string($_GET['since']) && $_GET['since'] === (string) $state['rev']) {
        return ['same' => true, 'rev' => $state['rev'], 'csrf' => $csrf];
    }
    return ['state' => $state, 'csrf' => $csrf];
});
