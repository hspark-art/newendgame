# 기본 시스템 아키텍처 v0.1

## 범위

PHP 8.1+ 코어, vanilla JS/CSS, SQLite PDO로 상대 종족 승률 CG 한 종류를 구현한다. 기존 `../www/`는 변경하지 않는다. 이번 승인 범위는 실행 가능한 기본 시스템이다. 수동 수정·외부 소스·MySQL·LAN 실행기는 후속 검토 대상으로 남긴다.

## 흐름

```text
MOCK JSON → provider 검증 → stats → 인스턴스 AUTO → PHP Presenter
                                                        ↓
페이지 번호 큐 ──────────────────────────────────── PREVIEW
                                                        ↓ TAKE
                                             PROGRAM 고정 스냅샷
                                                        ↓
                                            1920×1080 투명 출력
```

실제 전적·Alias·폰트·외부 URL을 추측하지 않는다. 상대 종족 승률은 사용자가 확정한 세트(개별 게임) 승·패 합계로 집계한다. 다른 CG의 집계 단위는 개별 확인한다. Presenter에서 반올림과 표시 문자열을 생성하고 JS는 수집·통계 계산을 하지 않는다. 지정한 실제 소스의 원본 구조·수치는 아직 미확인이다.

## 폴링과 상태

- 패널은 1초, 출력은 300ms 간격으로 이전 요청이 완료된 뒤 폴링한다.
- `since=rev`가 같으면 `same:true`를 반환한다.
- 상태 변경·로그·리비전 증가를 SQLite BEGIN IMMEDIATE 트랜잭션으로 묶는다.
- 읽기는 별도 읽기 트랜잭션으로 동일 시점의 상태를 반환한다.
- 요청은 `expected_rev`를 보내고, TAKE는 추가로 `expected_preview_rev`를 검사한다. 오래된 요청은 409로 거부한다.
- 페이지 번호의 정체성과 인스턴스의 정체성을 분리한다. 동일 파라미터를 가진 여러 페이지도 NEXT가 구분한다.
- 프로그램 스냅샷에 template/params/final/view/html/display/in/page_no를 고정한다. 새 TAKE마다 take_id를 발급한다.
- 큐·페이지 추가는 PREVIEW만 변경하고, SHOW/OUT은 PROGRAM의 표시 상태만 변경한다.
- 재시작 시 SQLite 상태를 복원한다. 정상 응답을 받지 못하면 열린 출력 페이지는 마지막 렌더링을 유지한다.

## 데이터 저장

`cg_settings`, `cg_sessions`, `cg_instances`, `cg_rundown`, `cg_channels`, `cg_sources`, `cg_logs`를 사용한다. 상세 정의는 `www/app/db.php`의 migration 1이다. 모든 테이블은 `cg_` 접두사이며 기존 앱 자료와 분리된다. SQLite WAL, foreign_keys, busy_timeout을 사용한다.

`cg_overrides`와 수동 수정은 아직 구현하지 않았다. 향후 세션·인스턴스·필드 단위로 추가한다. MySQL 스키마와 연결은 후속 구현이며 현재 SQLite 환경에서만 검증한다.

## 보안과 실행

router는 공개 경로 허용목록을 사용하며 내부 파일·변형 경로는 거부한다. 패널·상태·제어 API는 실제 루프백 접속만 허용한다. Host/포트 허용목록, Origin 일치, JSON Content-Type, HMAC CSRF를 확인한다. CSRF 비밀값은 DB에 보관하고 응답에 노출하지 않는다. 공개 출력 응답에는 조작 토큰을 포함하지 않는다.

PHP 내장 서버는 127.0.0.1:3100에 바인딩한다. Windows bat는 포터블 PHP의 절대 extension_dir를 지정하며 PHP 실행기가 준비 확인 후 Edge를 연다. 설치 바이너리·SQLite·로컬 config·로그·세션은 Git에서 제외한다.

클라우드는 기존 체크아웃을 사용한다. 별도 worktree를 만들지 않는다. 유지되는 파일과 종료 후 다시 실행해야 하는 서버 프로세스를 구분하고, 검증한 설치·재시작 명령을 환경 설정에 저장한다.

## 검증 한계

통계·상태·HTTP·보안 검사는 임시 DB로 실행한다. 브라우저 검증은 클라우드 Linux에서 수행한다. Windows 실행·Edge·OBS/vMix 실송출은 별도 환경의 검수 대상이다. 실제 데이터 소스와 방송 폰트는 미확정이다.
